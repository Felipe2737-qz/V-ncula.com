
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Brain, Globe, User, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import AuthModal from '@/components/AuthModal';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const location = useLocation();
  const { language, switchLanguage, t } = useLanguage();
  const { user, logout } = useAuth();

  const navItems = [
    { path: '/', label: t.nav.home },
    { path: '/how-it-works', label: t.nav.howItWorks },
    { path: '/ai-assistant', label: t.nav.aiAssistant },
    { path: '/about', label: t.nav.about },
  ];

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'pt', name: 'Português', flag: '🇧🇷' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <>
      <nav className="bg-slate-900/95 backdrop-blur-sm border-b border-blue-900/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 p-2 rounded-lg group-hover:shadow-lg group-hover:shadow-blue-500/50 transition-all duration-300">
                <Brain className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                Víncula
              </span>
            </Link>

            <div className="hidden md:flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                      isActive(item.path)
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/50'
                        : 'text-gray-300 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
              
              <div className="h-6 w-px bg-slate-700 mx-2" />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white hover:bg-slate-800 border border-slate-700">
                    <Globe className="h-4 w-4 mr-2" />
                    {language.toUpperCase()}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-slate-900 border-slate-700 text-gray-200 max-h-[300px] overflow-y-auto">
                  {languages.map((lang) => (
                    <DropdownMenuItem 
                      key={lang.code}
                      className={`cursor-pointer hover:bg-slate-800 focus:bg-slate-800 ${language === lang.code ? 'bg-slate-800 font-bold' : ''}`}
                      onClick={() => switchLanguage(lang.code)}
                    >
                      <span className="mr-2">{lang.flag}</span>
                      {lang.name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 bg-slate-900 border-slate-700 text-gray-200" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none text-white">{user.name}</p>
                        <p className="text-xs leading-none text-gray-400">
                          {user.email}
                        </p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-slate-700" />
                    <DropdownMenuItem className="text-blue-400 focus:bg-slate-800 focus:text-blue-400">
                        Tokens: {user.tokens || 0}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-slate-700" />
                    <DropdownMenuItem onClick={logout} className="text-red-400 focus:bg-slate-800 focus:text-red-400 cursor-pointer">
                      <LogOut className="mr-2 h-4 w-4" />
                      {t.nav.logout}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button 
                    onClick={() => setIsAuthOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white ml-2"
                >
                    <User className="h-4 w-4 mr-2" />
                    {t.nav.login}
                </Button>
              )}
            </div>

            <div className="flex items-center md:hidden gap-2">
                {/* Mobile Language & Menu Logic simplified for brevity */}
               <Button
                variant="ghost"
                size="icon"
                className="text-gray-300 hover:text-white hover:bg-slate-800"
                onClick={() => setIsOpen(!isOpen)}
              >
                {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="md:hidden border-t border-blue-900/20 bg-slate-900"
            >
              <div className="px-4 py-4 space-y-2">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsOpen(false)}
                    className={`block px-4 py-3 rounded-lg text-sm font-medium transition-all duration-300 ${
                      isActive(item.path)
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/50'
                        : 'text-gray-300 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
                
                <div className="border-t border-slate-700 pt-2 mt-2">
                  {!user ? (
                     <Button 
                        onClick={() => { setIsAuthOpen(true); setIsOpen(false); }}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white justify-start"
                    >
                        <User className="h-4 w-4 mr-2" />
                        {t.nav.login}
                    </Button>
                  ) : (
                     <Button 
                        onClick={() => { logout(); setIsOpen(false); }}
                        variant="destructive"
                        className="w-full justify-start"
                    >
                        <LogOut className="h-4 w-4 mr-2" />
                        {t.nav.logout}
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </>
  );
};

export default Navigation;
