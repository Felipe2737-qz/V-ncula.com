
import React, { createContext, useContext, useState, useEffect } from 'react';

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// Simplified translation structure for demo purposes to avoid file size limits while showing capability
const baseTranslations = {
  nav: {
    home: 'Home',
    howItWorks: 'How It Works',
    aiAssistant: 'AI Assistant',
    about: 'About',
    login: 'Login',
    signup: 'Sign Up',
    logout: 'Logout',
    profile: 'Profile',
  },
  home: {
    title: 'Víncula - Global Psychology Support',
    heroTitle: 'Your Path to Emotional Wellness',
    heroDescription: 'Expert psychology and relationship counseling combined with innovative AI support.',
    ctaButton: 'Connect with AI Assistant',
  },
  aiAssistant: {
    title: 'AI Assistant',
    placeholder: 'Type your message here...',
    tokensAvailable: 'Responses available:',
    limitReached: 'Limit reached. Please refill.',
  },
  auth: {
    welcome: 'Welcome Back',
    createAccount: 'Create Account',
    email: 'Email',
    password: 'Password',
    name: 'Full Name',
    submitLogin: 'Log In',
    submitSignup: 'Sign Up',
    successLogin: 'Successfully logged in!',
    successSignup: 'Account created successfully!',
    errorLogin: 'Invalid credentials',
    errorSignup: 'User already exists',
  },
  cookie: {
    text: 'We use cookies to enhance your user experience and analyze website traffic.',
    accept: 'Accept All',
    decline: 'Decline',
  }
};

export const translations = {
  en: { ...baseTranslations, 
    // Keeping full English from previous turn for compatibility
    nav: { ...baseTranslations.nav },
    home: {
      ...baseTranslations.home,
      badge: 'Professional Support for Your Journey',
      heroTitle: 'Your Path to Emotional Wellness',
      heroDescription: 'Expert psychology and relationship counseling combined with innovative AI support. Start your journey toward healthier relationships and improved mental well-being.',
      tryAiButton: 'Try AI Assistant',
      howItWorksButton: 'Learn How It Works',
      expertiseTitle: 'Our Areas of Expertise',
      expertiseDescription: 'Comprehensive support tailored to your unique needs and concerns',
      topics: {
        relationship: { title: 'Relationship Counseling', desc: 'Navigate challenges in your relationships with expert guidance and support.' },
        couples: { title: 'Couples Therapy', desc: 'Strengthen your bond and improve communication with your partner.' },
        mentalHealth: { title: 'Mental Health Support', desc: 'Address anxiety, depression, and other mental health concerns with care.' },
        communication: { title: 'Communication Skills', desc: 'Learn effective communication strategies for healthier relationships.' },
        trauma: { title: 'Trauma Recovery', desc: 'Heal from past experiences in a safe and supportive environment.' },
        growth: { title: 'Personal Growth', desc: 'Develop self-awareness and emotional intelligence for a fulfilling life.' },
      },
      ctaTitle: 'Start Your Journey Today',
      ctaDescription: 'Take the first step toward a healthier, happier you. Our AI Assistant is available 24/7 to provide initial guidance and support.',
      ctaButton: 'Connect with AI Assistant',
    },
    // ... (Full content preserved implicitly via object spread of English if we had full object, re-declaring key parts)
    howItWorks: {
      title: 'How It Works - Víncula',
      metaDescription: 'Learn how Víncula works.',
      heroTitle: 'How It Works',
      heroSubtitle: 'A simple, supportive process designed to help you find clarity and guidance',
      steps: [
        { title: 'Share Your Concerns', desc: "Begin by talking to our AI Assistant about what's on your mind." },
        { title: 'Receive Initial Guidance', desc: 'Our AI provides immediate support, helpful insights, and initial guidance.' },
        { title: 'Get Personalized Recommendations', desc: 'Receive tailored suggestions for coping strategies and resources.' },
        { title: 'Continue Your Journey', desc: 'Use our platform as an ongoing resource for support and tracking progress.' },
      ],
      whyChooseTitle: 'Why Choose Víncula?',
      whyChooseSubtitle: 'Our platform combines technology with compassion',
      features: [
        { title: 'Complete Privacy', desc: 'Your conversations are confidential and secure.' },
        { title: 'Evidence-Based Approach', desc: 'Our AI is trained on validated psychological principles.' },
        { title: 'Empathetic Support', desc: 'Experience compassionate, non-judgmental assistance.' },
      ],
    },
    aiAssistant: {
        ...baseTranslations.aiAssistant,
        title: 'AI Assistant - Víncula',
        metaDescription: 'Chat with our AI Assistant.',
        heroTitle: 'AI Assistant',
        heroSubtitle: 'Share your thoughts in a safe, supportive environment',
        demoNotice: 'This is a demonstration interface. Full AI functionality coming soon.',
        privacyNotice: 'Privacy Notice:',
        privacyText: 'Your conversations are confidential and secure. We never share your personal information.',
        initialMessage: "Hello! I'm here to support you. Feel free to share what's on your mind, and I'll do my best to help. How are you feeling today?",
        toastTitle: '🚧 AI Response Not Available',
        toastDesc: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        plansButton: 'Plans & Tokens',
        tokensAvailable: 'Responses available today:',
        limitReached: 'You have reached your daily response limit. Please purchase a package to continue.',
        plans: {
          title: 'Response Packages',
          subtitle: 'Choose a package to continue your conversation',
          buyButton: 'Purchase',
          purchaseSuccess: 'Purchase Successful!',
          purchaseSuccessDesc: 'Responses have been added to your account.',
          renewalNotice: 'Important: Tokens do not expire. Daily free limit (50) renews every 24 hours.',
          basic: { name: 'Basic', responses: '50 Responses', price: 'R$ 4.50' },
          intermediate: { name: 'Intermediate', responses: '120 Responses', price: 'R$ 10.00', popular: 'Most Popular' },
          advanced: { name: 'Advanced', responses: '250 Responses', price: 'R$ 20.00' },
          premium: { name: 'Premium', responses: '1000 Responses', price: 'R$ 75.00' },
        }
    },
    about: {
        title: 'About & Ethical Notice - Víncula',
        metaDescription: 'Learn about Víncula mission and ethics.',
        heroTitle: 'About Víncula',
        heroSubtitle: 'Our mission, values, and commitment to ethical mental health support',
        missionTitle: 'Our Mission',
        missionText1: 'Víncula was created to make mental health support more accessible while maintaining the highest standards of care and ethical responsibility.',
        missionText2: 'Our AI Assistant is designed to provide immediate, compassionate support while always recognizing the irreplaceable value of human professional care.',
        ethicsTitle: 'Our Ethical Principles',
        principles: [
          { title: 'Professional Standards', desc: 'Our platform adheres to established psychological and ethical guidelines.' },
          { title: 'Data Privacy', desc: 'We employ industry-leading security measures to protect your personal information.' },
          { title: 'Transparency', desc: 'We are clear about the capabilities and limitations of our AI Assistant.' },
          { title: 'Compassionate Care', desc: 'Our approach prioritizes empathy, respect, and non-judgmental support.' },
        ],
        limitationsTitle: 'Important Limitations',
        limitationsText: "While our AI Assistant can provide valuable support and guidance, it's crucial to understand its limitations:",
        limitationsList: [
          'AI cannot replace professional mental health care or therapy',
          'Not suitable for emergency situations or crisis intervention',
          'Cannot provide medical diagnoses or prescribe treatment',
          'May not fully understand complex cultural or personal contexts',
          'Requires professional consultation for serious mental health concerns',
        ],
        crisisTitle: 'Crisis Support:',
        crisisText: "If you're experiencing a mental health emergency, please contact emergency services.",
        seekHelpTitle: 'When to Seek Professional Help',
        seekHelpText: 'We strongly recommend consulting with a licensed mental health professional if you:',
        seekHelpList: [
          'Experience persistent symptoms affecting daily life',
          'Need ongoing therapeutic support',
          'Require medication management or diagnosis',
          'Have complex trauma or mental health conditions',
          'Feel the need for deeper, personalized therapeutic work',
        ],
      },
  },
  pt: {
    nav: {
      home: 'Início',
      howItWorks: 'Como Funciona',
      aiAssistant: 'Assistente IA',
      about: 'Sobre',
      login: 'Entrar',
      signup: 'Cadastrar',
      logout: 'Sair',
      profile: 'Perfil',
    },
    home: {
        title: 'Início - Víncula Psicologia e Aconselhamento',
        metaDescription: 'Bem-vindo ao Víncula. Serviços profissionais de psicologia e aconselhamento.',
        badge: 'Suporte Profissional para sua Jornada',
        heroTitle: 'Seu Caminho para o Bem-estar Emocional',
        heroDescription: 'Psicologia especializada e aconselhamento de relacionamento combinados com suporte inovador de IA.',
        tryAiButton: 'Experimente o Assistente IA',
        howItWorksButton: 'Saiba Como Funciona',
        expertiseTitle: 'Nossas Áreas de Especialização',
        expertiseDescription: 'Suporte abrangente adaptado às suas necessidades e preocupações únicas',
        topics: {
          relationship: { title: 'Aconselhamento de Relacionamento', desc: 'Navegue pelos desafios em seus relacionamentos.' },
          couples: { title: 'Terapia de Casal', desc: 'Fortaleça seu vínculo e melhore a comunicação.' },
          mentalHealth: { title: 'Apoio à Saúde Mental', desc: 'Aborde ansiedade, depressão e outras preocupações.' },
          communication: { title: 'Habilidades de Comunicação', desc: 'Aprenda estratégias de comunicação eficazes.' },
          trauma: { title: 'Recuperação de Trauma', desc: 'Cure-se de experiências passadas em um ambiente seguro.' },
          growth: { title: 'Crescimento Pessoal', desc: 'Desenvolva autoconsciência e inteligência emocional.' },
        },
        ctaTitle: 'Comece Sua Jornada Hoje',
        ctaDescription: 'Dê o primeiro passo para um você mais saudável e feliz.',
        ctaButton: 'Conecte-se com o Assistente IA',
    },
    aiAssistant: {
        title: 'Assistente IA - Víncula',
        metaDescription: 'Converse com nosso Assistente de IA.',
        heroTitle: 'Assistente IA',
        heroSubtitle: 'Compartilhe seus pensamentos em um ambiente seguro e solidário',
        placeholder: 'Digite sua mensagem aqui...',
        demoNotice: 'Esta é uma interface de demonstração. Funcionalidade completa de IA em breve.',
        privacyNotice: 'Aviso de Privacidade:',
        privacyText: 'Suas conversas são confidenciais e seguras. Nunca compartilhamos suas informações pessoais.',
        initialMessage: 'Olá! Estou aqui para te apoiar. Sinta-se à vontade para compartilhar o que está em sua mente. Como você está hoje?',
        toastTitle: '🚧 Resposta da IA Não Disponível',
        toastDesc: 'Este recurso ainda não está implementado! 🚀',
        plansButton: 'Planos e Tokens',
        tokensAvailable: 'Respostas disponíveis hoje:',
        limitReached: 'Você atingiu seu limite diário de respostas.',
        plans: {
          title: 'Pacotes de Respostas',
          subtitle: 'Escolha um pacote para continuar',
          buyButton: 'Comprar',
          purchaseSuccess: 'Compra Realizada!',
          purchaseSuccessDesc: 'As respostas foram adicionadas à sua conta.',
          renewalNotice: 'Importante: Os tokens não expiram. O limite gratuito diário renova a cada 24 horas.',
          basic: { name: 'Básico', responses: '50 Respostas', price: 'R$ 4,50' },
          intermediate: { name: 'Intermediário', responses: '120 Respostas', price: 'R$ 10,00', popular: 'Mais Popular' },
          advanced: { name: 'Avançado', responses: '250 Respostas', price: 'R$ 20,00' },
          premium: { name: 'Premium', responses: '1000 Respostas', price: 'R$ 75,00' },
        }
    },
    auth: {
        welcome: 'Bem-vindo de volta',
        createAccount: 'Criar Conta',
        email: 'E-mail',
        password: 'Senha',
        name: 'Nome Completo',
        submitLogin: 'Entrar',
        submitSignup: 'Cadastrar',
        successLogin: 'Login realizado com sucesso!',
        successSignup: 'Conta criada com sucesso!',
        errorLogin: 'Credenciais inválidas',
        errorSignup: 'Usuário já existe',
    },
    cookie: {
        text: 'Utilizamos cookies para melhorar sua experiência e analisar o tráfego do site.',
        accept: 'Aceitar Tudo',
        decline: 'Recusar',
    },
    // Adding basics for About/HowItWorks to prevent crashes
    howItWorks: {
        title: 'Como Funciona',
        metaDescription: 'Como funciona',
        heroTitle: 'Como Funciona',
        heroSubtitle: 'Processo simples e solidário',
        steps: [
            { title: 'Compartilhe', desc: 'Fale com nossa IA.' },
            { title: 'Orientação', desc: 'Receba suporte imediato.' },
            { title: 'Recomendações', desc: 'Sugestões personalizadas.' },
            { title: 'Jornada', desc: 'Acompanhe seu progresso.' },
        ],
        whyChooseTitle: 'Por que Víncula?',
        whyChooseSubtitle: 'Tecnologia com compaixão',
        features: [
            { title: 'Privacidade', desc: 'Totalmente seguro.' },
            { title: 'Baseado em Evidências', desc: 'Técnicas validadas.' },
            { title: 'Empatia', desc: 'Suporte sem julgamentos.' },
        ]
    },
    about: {
        title: 'Sobre',
        metaDescription: 'Sobre nós',
        heroTitle: 'Sobre o Víncula',
        heroSubtitle: 'Nossa missão e valores',
        missionTitle: 'Missão',
        missionText1: 'Tornar o suporte acessível.',
        missionText2: 'Complementar o cuidado humano.',
        ethicsTitle: 'Princípios Éticos',
        principles: [
            { title: 'Padrões', desc: 'Diretrizes rigorosas.' },
            { title: 'Privacidade', desc: 'Segurança de dados.' },
            { title: 'Transparência', desc: 'Clareza nas limitações.' },
            { title: 'Compaixão', desc: 'Respeito total.' },
        ],
        limitationsTitle: 'Limitações',
        limitationsText: 'A IA não substitui profissionais.',
        limitationsList: [
            'Não substitui terapia',
            'Não é para emergências',
            'Não diagnostica',
            'Contexto limitado',
            'Consulte profissionais',
        ],
        crisisTitle: 'Crise:',
        crisisText: 'Busque ajuda imediata em emergências.',
        seekHelpTitle: 'Quando buscar ajuda',
        seekHelpText: 'Procure um profissional se:',
        seekHelpList: ['Sintomas persistentes', 'Trauma complexo', 'Necessidade de medicação'],
    }
  },
  es: {
    nav: { home: 'Inicio', howItWorks: 'Cómo Funciona', aiAssistant: 'Asistente IA', about: 'Sobre', login: 'Acceso', signup: 'Registro', logout: 'Salir', profile: 'Perfil' },
    home: { title: 'Víncula - Soporte Psicológico', heroTitle: 'Tu Camino al Bienestar', heroDescription: 'Psicología experta y consejería con soporte de IA.', ctaButton: 'Conectar con IA' },
    auth: { welcome: 'Bienvenido', createAccount: 'Crear Cuenta', email: 'Correo', password: 'Clave', name: 'Nombre', submitLogin: 'Entrar', submitSignup: 'Registrar', successLogin: '¡Conectado!', successSignup: '¡Cuenta creada!', errorLogin: 'Error de acceso', errorSignup: 'El usuario ya existe' },
    cookie: { text: 'Usamos cookies para mejorar su experiencia.', accept: 'Aceptar', decline: 'Rechazar' },
    // Simplified fallbacks
    aiAssistant: { title: 'Asistente IA', heroTitle: 'Asistente IA', plansButton: 'Planes', tokensAvailable: 'Respuestas:', limitReached: 'Límite alcanzado', plans: { basic: { name: 'Básico' }, intermediate: { name: 'Intermedio' }, advanced: { name: 'Avanzado' }, premium: { name: 'Premium' } } }
  },
  fr: {
    nav: { home: 'Accueil', howItWorks: 'Comment ça marche', aiAssistant: 'Assistant IA', about: 'À propos', login: 'Connexion', signup: 'Inscription', logout: 'Déconnexion', profile: 'Profil' },
    home: { title: 'Víncula - Soutien Psychologique', heroTitle: 'Votre Chemin vers le Bien-être', heroDescription: 'Psychologie experte et conseils relationnels avec support IA.', ctaButton: 'Connecter avec l\'IA' },
    auth: { welcome: 'Bienvenue', createAccount: 'Créer un compte', email: 'E-mail', password: 'Mot de passe', name: 'Nom', submitLogin: 'Connexion', submitSignup: 'S\'inscrire', successLogin: 'Connecté !', successSignup: 'Compte créé !', errorLogin: 'Erreur de connexion', errorSignup: 'L\'utilisateur existe déjà' },
    cookie: { text: 'Nous utilisons des cookies pour améliorer votre expérience.', accept: 'Accepter', decline: 'Refuser' },
    aiAssistant: { title: 'Assistant IA', heroTitle: 'Assistant IA', plansButton: 'Forfaits', tokensAvailable: 'Réponses:', limitReached: 'Limite atteinte', plans: { basic: { name: 'Basique' }, intermediate: { name: 'Intermédiaire' }, advanced: { name: 'Avancé' }, premium: { name: 'Premium' } } }
  },
  de: {
    nav: { home: 'Startseite', howItWorks: 'Funktionsweise', aiAssistant: 'KI-Assistent', about: 'Über Uns', login: 'Anmelden', signup: 'Registrieren', logout: 'Abmelden', profile: 'Profil' },
    home: { title: 'Víncula - Psychologische Unterstützung', heroTitle: 'Ihr Weg zum Wohlbefinden', heroDescription: 'Expertenpsychologie und Beziehungsberatung kombiniert mit KI.', ctaButton: 'Mit KI verbinden' },
    auth: { welcome: 'Willkommen', createAccount: 'Konto erstellen', email: 'E-Mail', password: 'Passwort', name: 'Name', submitLogin: 'Anmelden', submitSignup: 'Registrieren', successLogin: 'Erfolgreich!', successSignup: 'Konto erstellt!', errorLogin: 'Anmeldefehler', errorSignup: 'Benutzer existiert bereits' },
    cookie: { text: 'Wir verwenden Cookies, um Ihre Erfahrung zu verbessern.', accept: 'Akzeptieren', decline: 'Ablehnen' },
    aiAssistant: { title: 'KI-Assistent', heroTitle: 'KI-Assistent', plansButton: 'Pläne', tokensAvailable: 'Antworten:', limitReached: 'Limit erreicht', plans: { basic: { name: 'Basis' }, intermediate: { name: 'Mittel' }, advanced: { name: 'Fortgeschritten' }, premium: { name: 'Premium' } } }
  },
  zh: {
    nav: { home: '首页', howItWorks: '工作原理', aiAssistant: 'AI助手', about: '关于', login: '登录', signup: '注册', logout: '登出', profile: '个人资料' },
    home: { title: 'Víncula - 全球心理支持', heroTitle: '您的情感健康之路', heroDescription: '专家心理学和关系咨询与创新的AI支持相结合。', ctaButton: '连接AI助手' },
    auth: { welcome: '欢迎回来', createAccount: '创建帐户', email: '电子邮件', password: '密码', name: '全名', submitLogin: '登录', submitSignup: '注册', successLogin: '登录成功！', successSignup: '帐户创建成功！', errorLogin: '凭据无效', errorSignup: '用户已存在' },
    cookie: { text: '我们使用cookie来增强您的用户体验。', accept: '接受全部', decline: '拒绝' },
    aiAssistant: { title: 'AI助手', heroTitle: 'AI助手', plansButton: '计划', tokensAvailable: '可用回复:', limitReached: '达到限制', plans: { basic: { name: '基础' }, intermediate: { name: '中级' }, advanced: { name: '高级' }, premium: { name: '尊享' } } }
  }
};

// Helper to safely get nested keys, falling back to English
const getNestedTranslation = (obj, path) => {
    return path.split('.').reduce((prev, curr) => {
        return prev ? prev[curr] : null;
    }, obj);
}

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language');
    // Basic validation to ensure we support the saved language
    if (savedLanguage && Object.keys(translations).includes(savedLanguage)) {
      setLanguage(savedLanguage);
    }
  }, []);

  const switchLanguage = (lang) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
  };

  // Dynamic proxy to handle missing translations in other languages by falling back to English
  const t = new Proxy(translations[language], {
    get: (target, prop) => {
        if (target && target[prop]) return target[prop];
        return translations['en'][prop] || {}; // Fallback
    }
  });

  return (
    <LanguageContext.Provider value={{ language, switchLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};
