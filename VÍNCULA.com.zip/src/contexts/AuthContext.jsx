
import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from '@/components/ui/use-toast';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user from local storage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = (email, password) => {
    const accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
    const foundUser = accounts.find(u => u.email === email && u.password === password);
    
    if (foundUser) {
      // Don't store password in session
      const { password, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('currentUser', JSON.stringify(userWithoutPassword));
      return true;
    }
    return false;
  };

  const signup = (name, email, password) => {
    const accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
    
    if (accounts.some(u => u.email === email)) {
      return false; // User exists
    }

    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password, // In a real app, never store plain text passwords!
      tokens: 50, // Default free tokens
      joinedAt: new Date().toISOString()
    };

    accounts.push(newUser);
    localStorage.setItem('accounts', JSON.stringify(accounts));
    
    // Auto login after signup
    const { password: _, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
    localStorage.setItem('currentUser', JSON.stringify(userWithoutPassword));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
    toast({
      title: "Logged out",
      description: "See you soon!",
    });
  };

  const updateTokens = (amount) => {
    if (!user) return;
    
    const updatedUser = { ...user, tokens: user.tokens + amount };
    setUser(updatedUser);
    localStorage.setItem('currentUser', JSON.stringify(updatedUser));

    // Also update in the main accounts database
    const accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
    const updatedAccounts = accounts.map(acc => 
      acc.email === user.email ? { ...acc, tokens: acc.tokens + amount } : acc
    );
    localStorage.setItem('accounts', JSON.stringify(updatedAccounts));
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateTokens, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};
