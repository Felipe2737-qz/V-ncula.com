import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Shield, Heart, AlertCircle, Lock, UserCheck, BookOpen } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

const AboutPage = () => {
  const { t } = useLanguage();

  const ethicalPrinciples = [
    {
      icon: Shield,
      title: t.about.principles[0].title,
      description: t.about.principles[0].desc,
    },
    {
      icon: Lock,
      title: t.about.principles[1].title,
      description: t.about.principles[1].desc,
    },
    {
      icon: UserCheck,
      title: t.about.principles[2].title,
      description: t.about.principles[2].desc,
    },
    {
      icon: Heart,
      title: t.about.principles[3].title,
      description: t.about.principles[3].desc,
    },
  ];

  return (
    <>
      <Helmet>
        <title>{t.about.title}</title>
        <meta name="description" content={t.about.metaDescription} />
      </Helmet>

      <div className="min-h-screen bg-slate-950">
        <section className="relative overflow-hidden bg-gradient-to-b from-blue-950 to-slate-950 py-20">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSg1OSwgMTMwLCAyNDYsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>
          
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-blue-300 to-cyan-400 bg-clip-text text-transparent">
                {t.about.heroTitle}
              </h1>
              <p className="text-xl text-gray-300">
                {t.about.heroSubtitle}
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="bg-slate-900/50 border-slate-800 mb-12">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">{t.about.missionTitle}</CardTitle>
                </CardHeader>
                <CardContent className="text-gray-300 space-y-4">
                  <p>{t.about.missionText1}</p>
                  <p>{t.about.missionText2}</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="mb-16"
            >
              <h2 className="text-3xl font-bold mb-8 text-white text-center">
                {t.about.ethicsTitle}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {ethicalPrinciples.map((principle, index) => {
                  const Icon = principle.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                    >
                      <Card className="bg-slate-900/50 border-slate-800 h-full">
                        <CardHeader>
                          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700 p-2.5 mb-3">
                            <Icon className="w-full h-full text-white" />
                          </div>
                          <CardTitle className="text-white text-xl">{principle.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <CardDescription className="text-gray-400">
                            {principle.description}
                          </CardDescription>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Card className="bg-gradient-to-br from-orange-900/30 to-red-900/30 border-orange-700/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <AlertCircle className="h-8 w-8 text-orange-400" />
                    <CardTitle className="text-white text-2xl">{t.about.limitationsTitle}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300">
                    {t.about.limitationsText}
                  </p>
                  <ul className="space-y-3">
                    {t.about.limitationsList.map((limitation, index) => (
                      <li key={index} className="flex items-start gap-3 text-gray-300">
                        <span className="text-orange-400 mt-1">•</span>
                        <span>{limitation}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-6 p-4 bg-red-900/30 border border-red-700/50 rounded-lg">
                    <p className="text-red-300 font-medium">
                      <strong>{t.about.crisisTitle}</strong> {t.about.crisisText}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="mt-12"
            >
              <Card className="bg-slate-900/50 border-slate-800">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <BookOpen className="h-8 w-8 text-blue-400" />
                    <CardTitle className="text-white text-2xl">{t.about.seekHelpTitle}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="text-gray-300 space-y-3">
                  <p>{t.about.seekHelpText}</p>
                  <ul className="space-y-2 ml-4">
                    {t.about.seekHelpList.map((item, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-blue-400">→</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default AboutPage;