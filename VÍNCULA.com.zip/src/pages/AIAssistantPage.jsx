import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Ticket, CreditCard, Sparkles, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const AIAssistantPage = () => {
  const { t } = useLanguage();
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [tokens, setTokens] = useState(50);
  const [isPlansOpen, setIsPlansOpen] = useState(false);

  const packages = [
    {
      id: 'basic',
      name: t.aiAssistant.plans.basic.name,
      responses: 50,
      responsesText: t.aiAssistant.plans.basic.responses,
      price: t.aiAssistant.plans.basic.price,
      color: 'from-blue-500 to-cyan-500',
    },
    {
      id: 'intermediate',
      name: t.aiAssistant.plans.intermediate.name,
      responses: 120,
      responsesText: t.aiAssistant.plans.intermediate.responses,
      price: t.aiAssistant.plans.intermediate.price,
      color: 'from-purple-500 to-indigo-500',
      popular: true,
    },
    {
      id: 'advanced',
      name: t.aiAssistant.plans.advanced.name,
      responses: 250,
      responsesText: t.aiAssistant.plans.advanced.responses,
      price: t.aiAssistant.plans.advanced.price,
      color: 'from-orange-500 to-amber-500',
    },
    {
      id: 'premium',
      name: t.aiAssistant.plans.premium.name,
      responses: 1000,
      responsesText: t.aiAssistant.plans.premium.responses,
      price: t.aiAssistant.plans.premium.price,
      color: 'from-emerald-500 to-teal-500',
    },
  ];

  // Update initial message when language changes
  useEffect(() => {
    // Only set initial message if chat is empty
    if (messages.length === 0) {
      setMessages([
        {
          role: 'assistant',
          content: t.aiAssistant.initialMessage,
        },
      ]);
    } else if (messages.length === 1 && messages[0].role === 'assistant') {
       setMessages([{ ...messages[0], content: t.aiAssistant.initialMessage }]);
    }
  }, [t.aiAssistant.initialMessage, messages.length]);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    if (tokens <= 0) {
      toast({
        title: "Limit Reached",
        description: t.aiAssistant.limitReached,
        variant: "destructive",
        duration: 4000,
      });
      setIsPlansOpen(true);
      return;
    }

    const userMessage = {
      role: 'user',
      content: inputValue,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setTokens(prev => Math.max(0, prev - 1));

    toast({
      title: t.aiAssistant.toastTitle,
      description: t.aiAssistant.toastDesc,
      duration: 4000,
    });
  };

  const handlePurchase = (pkg) => {
    setTokens(prev => prev + pkg.responses);
    setIsPlansOpen(false);
    toast({
      title: t.aiAssistant.plans.purchaseSuccess,
      description: `${pkg.responsesText} - ${t.aiAssistant.plans.purchaseSuccessDesc}`,
      className: "bg-green-600 border-green-500 text-white",
    });
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      <Helmet>
        <title>{t.aiAssistant.title}</title>
        <meta name="description" content={t.aiAssistant.metaDescription} />
      </Helmet>

      <div className="min-h-screen bg-slate-950">
        <section className="relative overflow-hidden bg-gradient-to-b from-blue-950 to-slate-950 py-12">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSg1OSwgMTMwLCAyNDYsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>
          
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="text-center md:text-left"
              >
                <h1 className="text-3xl sm:text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 via-blue-300 to-cyan-400 bg-clip-text text-transparent">
                  {t.aiAssistant.heroTitle}
                </h1>
                <p className="text-gray-300 text-sm sm:text-base">
                  {t.aiAssistant.heroSubtitle}
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <Dialog open={isPlansOpen} onOpenChange={setIsPlansOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="bg-slate-900/50 border-blue-500/50 hover:bg-blue-900/30 text-blue-300 hover:text-white transition-all duration-300"
                    >
                      <Ticket className="mr-2 h-4 w-4" />
                      {t.aiAssistant.plansButton}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-slate-950 border-slate-800 text-gray-100 max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-2xl text-center font-bold text-white mb-2">
                        {t.aiAssistant.plans.title}
                      </DialogTitle>
                      <DialogDescription className="text-center text-gray-400 mb-6">
                        {t.aiAssistant.plans.subtitle}
                      </DialogDescription>
                    </DialogHeader>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-2">
                      {packages.map((pkg) => (
                        <Card 
                          key={pkg.id} 
                          className={`bg-slate-900 border-slate-800 relative flex flex-col ${pkg.popular ? 'border-purple-500/50 shadow-lg shadow-purple-500/10' : ''}`}
                        >
                          {pkg.popular && (
                            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                              <span className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                                {t.aiAssistant.plans.intermediate.popular}
                              </span>
                            </div>
                          )}
                          <CardHeader className="text-center pb-2 pt-8">
                            <h3 className="font-bold text-lg text-gray-200">{pkg.name}</h3>
                            <div className={`text-3xl font-bold bg-gradient-to-br ${pkg.color} bg-clip-text text-transparent my-2`}>
                              {pkg.price}
                            </div>
                          </CardHeader>
                          <CardContent className="text-center flex-1">
                            <div className="flex items-center justify-center gap-2 mb-4">
                              <Sparkles className="h-4 w-4 text-blue-400" />
                              <span className="text-gray-300 font-medium">{pkg.responsesText}</span>
                            </div>
                          </CardContent>
                          <CardFooter>
                            <Button 
                              className={`w-full bg-gradient-to-r ${pkg.color} hover:opacity-90 transition-opacity`}
                              onClick={() => handlePurchase(pkg)}
                            >
                              {t.aiAssistant.plans.buyButton}
                            </Button>
                          </CardFooter>
                        </Card>
                      ))}
                    </div>

                    <div className="mt-6 bg-blue-900/20 border border-blue-700/30 rounded-lg p-4 flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-blue-400 shrink-0 mt-0.5" />
                      <p className="text-sm text-blue-200">
                        {t.aiAssistant.plans.renewalNotice}
                      </p>
                    </div>
                  </DialogContent>
                </Dialog>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-8 pb-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="bg-slate-900/50 border-slate-800 shadow-xl">
                <div className="h-[500px] flex flex-col">
                  <div className="flex-1 overflow-y-auto p-6 space-y-4">
                    {messages.map((message, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`flex gap-3 ${
                          message.role === 'user' ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        {message.role === 'assistant' && (
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center flex-shrink-0">
                            <Bot className="h-5 w-5 text-white" />
                          </div>
                        )}
                        <div
                          className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                            message.role === 'user'
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-800 text-gray-100'
                          }`}
                        >
                          <p className="text-sm leading-relaxed">{message.content}</p>
                        </div>
                        {message.role === 'user' && (
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0">
                            <User className="h-5 w-5 text-white" />
                          </div>
                        )}
                      </motion.div>
                    ))}
                  </div>

                  <div className="border-t border-slate-800 p-4">
                    <div className="flex justify-between items-center mb-3 px-1">
                      <div className="flex items-center gap-2 text-xs font-medium text-gray-400">
                        <span>{t.aiAssistant.tokensAvailable}</span>
                        <span className={`px-2 py-0.5 rounded-full ${tokens > 10 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                          {tokens}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <textarea
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder={t.aiAssistant.placeholder}
                        disabled={tokens <= 0}
                        className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent resize-none disabled:opacity-50 disabled:cursor-not-allowed"
                        rows="2"
                      />
                      <Button
                        onClick={handleSend}
                        disabled={tokens <= 0}
                        className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-6 self-end disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="h-5 w-5" />
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-2 text-center">
                      {t.aiAssistant.demoNotice}
                    </p>
                  </div>
                </div>
              </Card>

              <div className="mt-6 bg-blue-900/20 border border-blue-700/30 rounded-xl p-4">
                <p className="text-sm text-blue-300 text-center">
                  <strong>{t.aiAssistant.privacyNotice}</strong> {t.aiAssistant.privacyText}
                </p>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default AIAssistantPage;