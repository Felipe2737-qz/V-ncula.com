import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MessageSquare, UserCheck, ClipboardCheck, Heart, Shield, Lightbulb } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

const HowItWorksPage = () => {
  const { t } = useLanguage();

  const steps = [
    {
      icon: MessageSquare,
      title: t.howItWorks.steps[0].title,
      description: t.howItWorks.steps[0].desc,
      color: 'from-blue-500 to-cyan-600',
    },
    {
      icon: UserCheck,
      title: t.howItWorks.steps[1].title,
      description: t.howItWorks.steps[1].desc,
      color: 'from-purple-500 to-indigo-600',
    },
    {
      icon: ClipboardCheck,
      title: t.howItWorks.steps[2].title,
      description: t.howItWorks.steps[2].desc,
      color: 'from-green-500 to-emerald-600',
    },
    {
      icon: Heart,
      title: t.howItWorks.steps[3].title,
      description: t.howItWorks.steps[3].desc,
      color: 'from-pink-500 to-rose-600',
    },
  ];

  const features = [
    {
      icon: Shield,
      title: t.howItWorks.features[0].title,
      description: t.howItWorks.features[0].desc,
    },
    {
      icon: Lightbulb,
      title: t.howItWorks.features[1].title,
      description: t.howItWorks.features[1].desc,
    },
    {
      icon: Heart,
      title: t.howItWorks.features[2].title,
      description: t.howItWorks.features[2].desc,
    },
  ];

  return (
    <>
      <Helmet>
        <title>{t.howItWorks.title}</title>
        <meta name="description" content={t.howItWorks.metaDescription} />
      </Helmet>

      <div className="min-h-screen bg-slate-950">
        <section className="relative overflow-hidden bg-gradient-to-b from-blue-950 to-slate-950 py-20">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSg1OSwgMTMwLCAyNDYsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>
          
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-blue-300 to-cyan-400 bg-clip-text text-transparent">
                {t.howItWorks.heroTitle}
              </h1>
              <p className="text-xl text-gray-300">
                {t.howItWorks.heroSubtitle}
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="space-y-12">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card className="bg-slate-900/50 border-slate-800 hover:border-blue-700/50 transition-all duration-300">
                      <CardHeader>
                        <div className="flex items-start gap-6">
                          <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${step.color} p-3 flex-shrink-0`}>
                            <Icon className="w-full h-full text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <span className="text-3xl font-bold text-blue-400">
                                {String(index + 1).padStart(2, '0')}
                              </span>
                              <CardTitle className="text-white text-2xl">{step.title}</CardTitle>
                            </div>
                            <CardDescription className="text-gray-400 text-base">
                              {step.description}
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-b from-slate-950 to-blue-950">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl sm:text-4xl font-bold mb-4 text-white">
                {t.howItWorks.whyChooseTitle}
              </h2>
              <p className="text-gray-400 text-lg">
                {t.howItWorks.whyChooseSubtitle}
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="bg-slate-900/50 border-slate-800 h-full text-center">
                      <CardHeader>
                        <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700 p-3 mx-auto mb-4">
                          <Icon className="w-full h-full text-white" />
                        </div>
                        <CardTitle className="text-white text-xl">{feature.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-gray-400">
                          {feature.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HowItWorksPage;