import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Users, Brain, MessageCircle, Shield, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';

const HomePage = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const topics = [
    {
      icon: Heart,
      title: t.home.topics.relationship.title,
      description: t.home.topics.relationship.desc,
      color: 'from-pink-500 to-rose-600',
    },
    {
      icon: Users,
      title: t.home.topics.couples.title,
      description: t.home.topics.couples.desc,
      color: 'from-purple-500 to-indigo-600',
    },
    {
      icon: Brain,
      title: t.home.topics.mentalHealth.title,
      description: t.home.topics.mentalHealth.desc,
      color: 'from-blue-500 to-cyan-600',
    },
    {
      icon: MessageCircle,
      title: t.home.topics.communication.title,
      description: t.home.topics.communication.desc,
      color: 'from-green-500 to-emerald-600',
    },
    {
      icon: Shield,
      title: t.home.topics.trauma.title,
      description: t.home.topics.trauma.desc,
      color: 'from-orange-500 to-amber-600',
    },
    {
      icon: Sparkles,
      title: t.home.topics.growth.title,
      description: t.home.topics.growth.desc,
      color: 'from-violet-500 to-purple-600',
    },
  ];

  return (
    <>
      <Helmet>
        <title>{t.home.title}</title>
        <meta name="description" content={t.home.metaDescription} />
      </Helmet>

      <div className="min-h-screen">
        <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-blue-950 to-slate-950 py-20 sm:py-32">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSg1OSwgMTMwLCAyNDYsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="inline-block mb-6"
              >
                <div className="bg-blue-600/20 border border-blue-500/30 rounded-full px-6 py-2 backdrop-blur-sm">
                  <span className="text-blue-400 font-medium">{t.home.badge}</span>
                </div>
              </motion.div>

              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-blue-300 to-cyan-400 bg-clip-text text-transparent">
                {t.home.heroTitle}
              </h1>
              
              <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
                {t.home.heroDescription}
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  onClick={() => navigate('/ai-assistant')}
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg shadow-blue-600/50 hover:shadow-blue-700/60 transition-all duration-300"
                >
                  <Brain className="mr-2 h-5 w-5" />
                  {t.home.tryAiButton}
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => navigate('/how-it-works')}
                  className="border-blue-500/50 text-blue-400 hover:bg-blue-600/10 hover:border-blue-400 transition-all duration-300"
                >
                  {t.home.howItWorksButton}
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-slate-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl sm:text-4xl font-bold mb-4 text-white">
                {t.home.expertiseTitle}
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                {t.home.expertiseDescription}
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {topics.map((topic, index) => {
                const Icon = topic.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="bg-slate-900/50 border-slate-800 hover:border-blue-700/50 transition-all duration-300 h-full group hover:shadow-lg hover:shadow-blue-600/10">
                      <CardHeader>
                        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${topic.color} p-2.5 mb-4 group-hover:scale-110 transition-transform duration-300`}>
                          <Icon className="w-full h-full text-white" />
                        </div>
                        <CardTitle className="text-white text-xl">{topic.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-gray-400">
                          {topic.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-b from-slate-950 to-blue-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-gradient-to-r from-blue-900/40 to-purple-900/40 border border-blue-700/30 rounded-2xl p-8 sm:p-12 backdrop-blur-sm"
            >
              <div className="max-w-3xl mx-auto text-center">
                <Brain className="h-16 w-16 mx-auto mb-6 text-blue-400" />
                <h2 className="text-3xl sm:text-4xl font-bold mb-4 text-white">
                  {t.home.ctaTitle}
                </h2>
                <p className="text-gray-300 text-lg mb-8">
                  {t.home.ctaDescription}
                </p>
                <Button
                  size="lg"
                  onClick={() => navigate('/ai-assistant')}
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg shadow-blue-600/50 hover:shadow-blue-700/60 transition-all duration-300"
                >
                  {t.home.ctaButton}
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;